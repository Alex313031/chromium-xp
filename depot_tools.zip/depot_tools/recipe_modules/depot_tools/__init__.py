DEPS = [
  'recipe_engine/platform',
]
